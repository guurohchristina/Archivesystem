const Home = () => {
  return (
    <div className="page">
      <h1>Welcome to Achieve System</h1>
      <p>Secure document archiving and management.</p>
    </div>
  );
};

export default Home;
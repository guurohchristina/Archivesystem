import { useState, useContext } from "react";
import { AuthContext } from "../context/AuthContext";

const Register = () => {
  const { register } = useContext(AuthContext);

  const [data, setData] = useState({
    name: "",
    email: "",
    password: "",
  });

  const submit = async (e) => {
    e.preventDefault();
    try {
      await register(data);
      alert("Registration successful!");
    } catch {
      alert("Registration failed.");
    }
  };

  return (
    <div className="page">
      <h1>Register</h1>

      <form className="form" onSubmit={submit}>
        <input
          type="text"
          placeholder="Name"
          onChange={(e)=>setData({...data, name: e.target.value})}
        />

        <input
          type="email"
          placeholder="Email"
          onChange={(e)=>setData({...data, email: e.target.value})}
        />

        <input
          type="password"
          placeholder="Password"
          onChange={(e)=>setData({...data, password: e.target.value})}
        />

        <button>Register</button>
      </form>
    </div>
  );
};

export default Register;
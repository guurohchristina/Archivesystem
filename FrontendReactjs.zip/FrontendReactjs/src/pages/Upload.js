import { useState } from "react";
import axiosClient from "../api/axiosClient";

const Upload = () => {
  const [file, setFile] = useState(null);
  const [title, setTitle] = useState("");
  const [department, setDepartment] = useState("");

  const submit = async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append("file", file);
    formData.append("title", title);
    formData.append("department", department);

    try {
      await axiosClient.post("/documents/upload", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      alert("Upload successful!");
    } catch {
      alert("Upload failed.");
    }
  };

  return (
    <div className="page">
      <h1>Upload Document</h1>

      <form className="form" onSubmit={submit}>
        <input
          type="text"
          placeholder="Document Title"
          onChange={(e)=>setTitle(e.target.value)}
        />

        <select onChange={(e)=>setDepartment(e.target.value)}>
          <option value="">Select Department</option>
          <option value="IT">IT</option>
          <option value="Finance">Finance</option>
          <option value="HR">HR</option>
        </select>

        <input
          type="file"
          onChange={(e)=>setFile(e.target.files[0])}
        />

        <button>Upload</button>
      </form>
    </div>
  );
};

export default Upload;